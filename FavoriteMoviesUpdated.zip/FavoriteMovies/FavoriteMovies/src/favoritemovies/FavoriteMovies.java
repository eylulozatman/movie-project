/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package favoritemovies;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;

/**
 *
 * @author DELL
 */
public class FavoriteMovies {
    
  

 public static void clearFiles() throws FileNotFoundException 
 {     
       File file = new File("C:\\Users\\DELL\\Desktop\\finalProject\\Movies.txt");
     try (PrintWriter writer = new PrintWriter(file)) {
         writer. print("");
     }
           
             File file1 = new File("C:\\Users\\DELL\\Desktop\\finalProject\\Stars.txt");
     try (PrintWriter writer1 = new PrintWriter(file1)) {
         writer1. print("");
     }
           
             File file2 = new File("C:\\Users\\DELL\\Desktop\\finalProject\\Ratings.txt");
     try (PrintWriter writer2 = new PrintWriter(file2)) {
         writer2. print("");
     }
           
 }
     
    public  static void main(String[] args) throws FileNotFoundException  {
        clearFiles();   
         new login().setVisible(true); 
        
           
    }
    
}
